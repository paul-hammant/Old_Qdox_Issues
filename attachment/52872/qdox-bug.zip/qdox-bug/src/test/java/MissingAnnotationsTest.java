import com.thoughtworks.qdox.JavaDocBuilder;
import org.junit.Test;

import java.io.File;

import static org.junit.Assert.assertEquals;

public class MissingAnnotationsTest {

    @Test
    public void packageInfoAnnotationsMissing() {

        //package y, package-info not first file, deprecated annotation found
        JavaDocBuilder builder = new JavaDocBuilder();
        builder.addSourceTree(new File("./src/main/java/com/y"));
        assertEquals(1, builder.getPackages()[0].getAnnotations().length);

         //package x, package-info not first file, test fails, deprecated annotation not found
        builder = new JavaDocBuilder();
        builder.addSourceTree(new File("./src/main/java/com/x"));
        assertEquals(1, builder.getPackages()[0].getAnnotations().length);

    }
}
