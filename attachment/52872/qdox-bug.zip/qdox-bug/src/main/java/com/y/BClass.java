package com.y;

public class BClass {


    public void someMethod() {

    }

}
