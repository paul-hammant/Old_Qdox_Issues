package com.bsb;

import com.bsb.package1.Class2;
import com.bsb.package1.Class2.InnerClass;

public class Class1 {
  public void testMethod(Class2.InnerClass param) {
  }
}
