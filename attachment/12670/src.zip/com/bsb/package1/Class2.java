package com.bsb.package1;

public class Class2 {

  public static final class InnerClass {

  }
}
