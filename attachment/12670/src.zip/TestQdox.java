
import java.io.File;

import com.thoughtworks.qdox.JavaDocBuilder;
import com.thoughtworks.qdox.model.JavaClass;
import com.thoughtworks.qdox.model.JavaMethod;

public class TestQdox {

  public static void main(String[] args) {
    JavaDocBuilder builder = new JavaDocBuilder();
    builder.addSourceTree(new File("C:\\Dev\\JavaTests\\src\\"));
    JavaClass cls = builder.getClassByName("com.bsb.Class1");
    JavaMethod methods[] = cls.getMethods();

    for (int i = 0; i < methods.length; i++) {
      JavaMethod method = methods[i];
      System.out.println("Method (decl) : " + method.getDeclarationSignature(true));
    }
  }
}
