package test;

import static test.TestUtil.getTestString;

/**
 * @hibernate.class  table="test"
 *
 * @author Espen Amble Kolstad
 *
 * @version $Revision: 1.4 $
 */
public class Test {
   private int id;
   private String field1;

   public Test() {
      field1 = getTestString();
   }

   /**
    * @hibernate.id column="id"
    *               generator-class="sequence"
    *
    * @hibernate.generator-param   name="sequence"
    *                              value="cellus_map_item_seq"
    */
   public int getId() {
      return id;
   }

   public void setId(int id) {
      this.id = id;
   }

   /**
    * @hibernate.property  column="field_1"
    */
   public String getField1() {
      return field1;
   }

   public void setField1(String field1) {
      this.field1 = field1;
   }

   public boolean equals(Object obj) {
      if (this == obj) return true;
      if (obj == null || getClass() != obj.getClass()) return false;

      final Test mapping = (Test) obj;
      return id == mapping.id;
   }

   public int hashCode() {
      return id;
   }
}