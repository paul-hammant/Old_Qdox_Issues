package test;

/**
 * @author Espen Amble Kolstad
 *
 * @version $Revision$
 */
public class TestUtil {

   public static String getTestString() {
      return "testString";
   }

   private TestUtil() {
   }
}