public enum BogusEnum
{
    /**
     * Blah blah
     */
    @MyAnno
    TEST;
}