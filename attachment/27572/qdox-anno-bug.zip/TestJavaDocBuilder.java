import junit.framework.TestCase;


import java.io.FileNotFoundException;
import java.io.FileReader;


import com.thoughtworks.qdox.JavaDocBuilder;
import com.thoughtworks.qdox.parser.ParseException;



public class TestJavaDocBuilder extends TestCase
{
    public void testAddSource() throws FileNotFoundException
    {
        JavaDocBuilder builder = new JavaDocBuilder();
        try
        {
            builder.addSource( new FileReader( "BogusEnum.java" ) );
        }
        catch( ParseException e )
        {
            fail( e.getMessage() );
        }

    }
}